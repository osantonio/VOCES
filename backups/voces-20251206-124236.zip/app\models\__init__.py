"""
Modelos de la aplicación VOCES.

Este paquete contiene todos los modelos de base de datos:
- Usuario: Autenticación y perfil público
- PerfilDemografico: Datos demográficos para encuestas
- LogActividad: Auditoría y registro de acciones
- Enums: RolUsuario, EstadoCuenta, Sexo, TipoAccion
- Mixins: TimestampMixin, RedesSocialesMixin, EstadisticasMixin
"""

# Importar enums
from app.models.enums import RolUsuario, EstadoCuenta, Sexo, TipoAccion

# Importar mixins
from app.models.base import TimestampMixin, RedesSocialesMixin, EstadisticasMixin

# Importar modelos
from app.models.usuario import Usuario, generar_uuid_personalizado
from app.models.perfil_demografico import PerfilDemografico
from app.models.log_actividad import LogActividad
from app.models.redes_sociales import CatalogoRedSocial, UsuarioRedSocial

# Importar eventos (esto registra los listeners automáticamente)
from app.models import eventos  # noqa: F401

__all__ = [
    # Enums
    "RolUsuario",
    "EstadoCuenta",
    "Sexo",
    "TipoAccion",
    # Mixins
    "TimestampMixin",
    "RedesSocialesMixin",
    "EstadisticasMixin",
    # Modelos
    "Usuario",
    "PerfilDemografico",
    "LogActividad",
    "CatalogoRedSocial",
    "UsuarioRedSocial",
    # Utilidades
    "generar_uuid_personalizado",
]
