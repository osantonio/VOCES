"""Paquete de scripts de utilidad."""
