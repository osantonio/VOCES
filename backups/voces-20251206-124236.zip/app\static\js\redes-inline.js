document.addEventListener('DOMContentLoaded', function () {
  var forms = document.querySelectorAll('.catalog-add-form');

  function getBaseFromPlaceholder(ph) {
    try {
      if (!ph) return null;
      var idx = ph.lastIndexOf('/');
      if (idx > 7) {
        return ph.slice(0, idx + 1);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  forms.forEach(function (form) {
    var ph = form.getAttribute('data-placeholder') || '';
    var base = getBaseFromPlaceholder(ph);
    var userInput = form.querySelector('input[name="usuario"]');
    var urlInput = form.querySelector('input[name="url"]');

    function update() {
      var username = (userInput && userInput.value || '').trim();
      if (base && username) {
        urlInput.value = base + username;
      }
    }

    if (urlInput && ph) {
      urlInput.placeholder = ph;
    }

    if (userInput) {
      userInput.addEventListener('input', update);
    }
  });
});
